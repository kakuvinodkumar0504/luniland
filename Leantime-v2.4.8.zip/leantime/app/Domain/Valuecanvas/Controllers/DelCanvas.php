<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Valuecanvas\Controllers {

    /**
     *
     */
    class DelCanvas extends \Leantime\Domain\Canvas\Controllers\DelCanvas
    {
        protected const CANVAS_NAME = 'value';
    }
}

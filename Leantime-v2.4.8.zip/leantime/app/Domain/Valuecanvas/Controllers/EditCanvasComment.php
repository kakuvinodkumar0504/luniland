<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Valuecanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'value';
    }

}

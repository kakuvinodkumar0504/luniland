<?php

/**
 * Controller
 */

namespace Leantime\Domain\Emcanvas\Controllers {

    /**
     *
     */
    class ShowCanvas extends \Leantime\Domain\Canvas\Controllers\ShowCanvas
    {
        protected const CANVAS_NAME = 'em';
    }

}

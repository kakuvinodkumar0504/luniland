<?php

/**
 * Strategy Brief - Controller / Delete Canvas
 */

namespace Leantime\Domain\Sbcanvas\Controllers {

    /**
     *
     */
    class DelCanvas extends \Leantime\Domain\Canvas\Controllers\DelCanvas
    {
        protected const CANVAS_NAME = 'sb';
    }
}

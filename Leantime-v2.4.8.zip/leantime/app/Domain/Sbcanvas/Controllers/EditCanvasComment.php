<?php

/**
 * Strategy Brief - Controller / Edit Comments
 */

namespace Leantime\Domain\Sbcanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'sb';
    }

}

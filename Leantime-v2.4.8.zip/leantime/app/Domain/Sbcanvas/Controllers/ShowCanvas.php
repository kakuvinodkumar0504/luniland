<?php

/**
 * Strategy Brief - Controller
 */

namespace Leantime\Domain\Sbcanvas\Controllers {

    /**
     *
     */
    class ShowCanvas extends \Leantime\Domain\Canvas\Controllers\ShowCanvas
    {
        protected const CANVAS_NAME = 'sb';
    }

}

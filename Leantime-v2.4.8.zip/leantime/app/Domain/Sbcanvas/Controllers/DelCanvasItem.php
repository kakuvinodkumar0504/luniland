<?php

/**
 * Strategy Brief - Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Sbcanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'sb';
    }

}

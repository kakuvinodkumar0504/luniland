<?php

/**
 * Strategy Brief - Controller / Edit Canvas Item
 */

namespace Leantime\Domain\Sbcanvas\Controllers {

    /**
     *
     */
    class EditCanvasItem extends \Leantime\Domain\Canvas\Controllers\EditCanvasItem
    {
        protected const CANVAS_NAME = 'sb';
    }

}

<?php

namespace Leantime\Domain\Wiki\Models {

    /**
     *
     */
    class Template
    {
        public $title;
        public $description;
        public $content;

        public function __construct()
        {
        }
    }

}

<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Obmcanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'obm';
    }

}

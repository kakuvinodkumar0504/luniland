<?php

/**
 * Controller / Edit Canvas Item
 */

namespace Leantime\Domain\Sqcanvas\Controllers {

    /**
     *
     */
    class EditCanvasItem extends \Leantime\Domain\Canvas\Controllers\EditCanvasItem
    {
        protected const CANVAS_NAME = 'sq';
    }

}

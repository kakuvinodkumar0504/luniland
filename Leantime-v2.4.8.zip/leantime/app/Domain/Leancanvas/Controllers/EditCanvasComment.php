<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Leancanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'lean';
    }

}

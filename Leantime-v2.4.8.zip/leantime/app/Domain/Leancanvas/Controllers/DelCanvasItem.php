<?php

/**
 * Controller / Delete Canvas Item
 */

namespace Leantime\Domain\Leancanvas\Controllers {

    /**
     *
     */
    class DelCanvasItem extends \Leantime\Domain\Canvas\Controllers\DelCanvasItem
    {
        protected const CANVAS_NAME = 'lean';
    }

}

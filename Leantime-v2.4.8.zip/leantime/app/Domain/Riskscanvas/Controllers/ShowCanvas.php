<?php

/**
 * Controller
 */

namespace Leantime\Domain\Riskscanvas\Controllers {

    /**
     *
     */
    class ShowCanvas extends \Leantime\Domain\Canvas\Controllers\ShowCanvas
    {
        protected const CANVAS_NAME = 'risks';
    }

}

<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Riskscanvas\Controllers {

    /**
     *
     */
    class DelCanvas extends \Leantime\Domain\Canvas\Controllers\DelCanvas
    {
        protected const CANVAS_NAME = 'risks';
    }
}

<?php

/**
 * - insightscanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Insightscanvas extends Canvas
    {
        protected const CANVAS_NAME = 'insights';
    }
}

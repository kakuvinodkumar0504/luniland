<?php

/**
 * - dbmcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Dbmcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'dbm';
    }
}

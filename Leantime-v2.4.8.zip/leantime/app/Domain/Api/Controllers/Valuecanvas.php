<?php

/**
 * - sqcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Valuecanvas extends Canvas
    {
        protected const CANVAS_NAME = 'value';
    }
}

<?php

/**
 * - emcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Emcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'em';
    }
}

<?php

/**
 * - riskscanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Riskscanvas extends Canvas
    {
        protected const CANVAS_NAME = 'risks';
    }
}

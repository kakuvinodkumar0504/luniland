<?php

/**
 * - lbmcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Lbmcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'lbm';
    }
}

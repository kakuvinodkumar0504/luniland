<?php

/**
 * - swotcanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Swotcanvas extends Canvas
    {
        protected const CANVAS_NAME = 'swot';
    }
}

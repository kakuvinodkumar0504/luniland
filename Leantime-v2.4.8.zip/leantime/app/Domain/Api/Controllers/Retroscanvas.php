<?php

/**
 * - retroscanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Retroscanvas extends Canvas
    {
        protected const CANVAS_NAME = 'retros';
    }
}

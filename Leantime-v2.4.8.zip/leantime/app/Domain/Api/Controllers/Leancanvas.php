<?php

/**
 * - leancanvas class - Controller API
 */

namespace Leantime\Domain\Api\Controllers {

    /**
     *
     */
    class Leancanvas extends Canvas
    {
        protected const CANVAS_NAME = 'lean';
    }
}

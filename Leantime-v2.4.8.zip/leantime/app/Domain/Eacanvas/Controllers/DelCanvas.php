<?php

/**
 * Controller / Delete Canvas
 */

namespace Leantime\Domain\Eacanvas\Controllers {

    /**
     *
     */
    class DelCanvas extends \Leantime\Domain\Canvas\Controllers\DelCanvas
    {
        protected const CANVAS_NAME = 'ea';
    }
}

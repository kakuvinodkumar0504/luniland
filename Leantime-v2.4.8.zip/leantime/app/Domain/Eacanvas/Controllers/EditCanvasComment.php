<?php

/**
 * Controller / Edit Comments
 */

namespace Leantime\Domain\Eacanvas\Controllers {

    /**
     *
     */
    class EditCanvasComment extends \Leantime\Domain\Canvas\Controllers\EditCanvasComment
    {
        protected const CANVAS_NAME = 'ea';
    }

}


<div class="pageheader">
    <div class="pageicon"><span class="fa fa-book"></span></div>
    <div class="pagetitle">


        <h1>Example plugin settings page</h1>

    </div>

</div>

<div class="maincontent">

    <div class="maincontentinner" style="text-align: center;">
        <h1>Actually, there are not settings for this plugin.</h1><br />
        <iframe width="560" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>

</div>



<?php

/**
 * MotivationalQuotes
 *
 * Plugin to greet you with a motivation quote on your home page.
 * Example plugin to show basic plugin structure.
 *
 */
